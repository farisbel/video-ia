import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wand2, Download, Copy, RefreshCw, Sparkles, Image, Palette, Zap, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const ThumbnailGenerator = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImages, setGeneratedImages] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState('realistic');

  const styles = [
    { id: 'realistic', name: 'Réaliste', color: 'from-blue-500 to-cyan-500' },
    { id: 'cartoon', name: 'Cartoon', color: 'from-purple-500 to-pink-500' },
    { id: 'cinematic', name: 'Cinématique', color: 'from-orange-500 to-red-500' },
    { id: 'artistic', name: 'Artistique', color: 'from-green-500 to-emerald-500' }
  ];

  const promptSuggestions = [
    "Un chat mignon avec des lunettes de soleil sur une plage tropicale",
    "Paysage futuriste avec des gratte-ciels lumineux au coucher du soleil",
    "Portrait d'un aventurier dans une forêt mystérieuse",
    "Cuisine moderne avec des plats colorés et appétissants",
    "Voiture de sport rouge sur une route de montagne",
    "Astronaute flottant dans l'espace avec des étoiles brillantes"
  ];

  const generateThumbnail = async () => {
    if (!prompt.trim()) {
      toast({
        title: "❌ Prompt requis",
        description: "Veuillez entrer une description pour générer votre miniature.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    setGeneratedImages([]);
    
    setTimeout(() => {
      const newImages = Array.from({ length: 4 }, (_, i) => ({
        id: Date.now() + i,
        prompt: prompt,
        style: selectedStyle
      }));
      
      setGeneratedImages(newImages);
      setIsGenerating(false);
      
      toast({
        title: "🎨 Miniatures générées !",
        description: "4 miniatures uniques ont été créées avec votre prompt.",
      });
    }, 2000);
  };

  const downloadImage = async (index) => {
    toast({
      title: "📥 Téléchargement...",
      description: `Miniature ${index + 1} en cours de téléchargement !`,
    });
    
    const response = await fetch(`https://source.unsplash.com/400x225/?${encodeURIComponent(generatedImages[index].prompt)}&sig=${index}`);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = `thumbnail-${generatedImages[index].prompt.split(' ')[0]}-${index + 1}.png`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);

    toast({
      title: "✅ Téléchargement terminé !",
      description: `Miniature ${index + 1} téléchargée.`,
    });
  };

  const copyPrompt = (suggestion) => {
    setPrompt(suggestion);
    toast({
      title: "📋 Prompt copié !",
      description: "Le prompt a été ajouté dans le champ de saisie.",
    });
  };

  const resetGenerator = () => {
    setPrompt('');
    setGeneratedImages([]);
    setSelectedStyle('realistic');
    toast({
      title: "✨ Réinitialisation terminée !",
      description: "Le générateur de miniatures est prêt pour une nouvelle création.",
    });
  };

  return (
    <div className="space-y-6">
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-2">
          Générateur de Miniatures IA
        </h2>
        <p className="text-purple-300">Créez des miniatures époustouflantes avec l'intelligence artificielle</p>
      </motion.div>

      <motion.div
        className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Palette className="w-5 h-5 mr-2 text-purple-400" />
          Style artistique
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {styles.map((style) => (
            <motion.button
              key={style.id}
              onClick={() => setSelectedStyle(style.id)}
              className={`p-4 rounded-xl border transition-all duration-300 ${
                selectedStyle === style.id
                  ? 'border-purple-500 bg-purple-500/20'
                  : 'border-white/10 bg-white/5 hover:border-purple-500/50'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className={`w-8 h-8 bg-gradient-to-r ${style.color} rounded-lg mx-auto mb-2`}></div>
              <span className="text-sm font-medium text-white">{style.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>

      <motion.div
        className="bg-gradient-to-br from-blue-900/50 to-indigo-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Wand2 className="w-5 h-5 mr-2 text-blue-400" />
          Décrivez votre miniature
        </h3>
        <div className="space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Décrivez en détail la miniature que vous souhaitez créer..."
            className="w-full h-32 bg-black/30 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-purple-300 focus:border-purple-500 focus:outline-none resize-none"
          />
          <div className="flex justify-between items-center flex-wrap gap-2">
            <Button
              onClick={resetGenerator}
              variant="outline"
              className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20 hover:text-white"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Réinitialiser
            </Button>
            <Button
              onClick={generateThumbnail}
              disabled={isGenerating}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-6 py-2 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Génération...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Générer 4 miniatures
                </>
              )}
            </Button>
          </div>
        </div>
      </motion.div>

      <motion.div
        className="bg-gradient-to-br from-green-900/50 to-emerald-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <Zap className="w-5 h-5 mr-2 text-green-400" />
          Suggestions de prompts
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {promptSuggestions.map((suggestion, index) => (
            <motion.button
              key={index}
              onClick={() => copyPrompt(suggestion)}
              className="text-left p-3 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-green-500/30 rounded-lg transition-all duration-300"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-start space-x-3">
                <Copy className="w-4 h-4 text-green-400 mt-1 flex-shrink-0" />
                <span className="text-sm text-white">{suggestion}</span>
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {(isGenerating || generatedImages.length > 0) && (
        <motion.div
          className="bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Image className="w-5 h-5 mr-2 text-purple-400" />
            Miniatures générées
          </h3>
          {isGenerating && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Array.from({ length: 4 }).map((_, index) => (
                <div key={index} className="w-full aspect-video bg-black/30 rounded-xl flex items-center justify-center">
                  <RefreshCw className="w-8 h-8 text-purple-400 animate-spin" />
                </div>
              ))}
            </div>
          )}
          {!isGenerating && generatedImages.length > 0 && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <motion.div
                  className="relative group"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.1 }}
                >
                  <img  alt={`Miniature générée 1`} className="w-full aspect-video object-cover rounded-xl shadow-lg" src="https://images.unsplash.com/photo-1663647235366-fbdae0050867" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl flex items-center justify-center">
                    <Button onClick={() => downloadImage(0)} className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                  <div className="absolute top-3 left-3 bg-black/70 text-white text-xs px-2 py-1 rounded-full">#1</div>
                </motion.div>
                <motion.div
                  className="relative group"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.2 }}
                >
                  <img  alt={`Miniature générée 2`} className="w-full aspect-video object-cover rounded-xl shadow-lg" src="https://images.unsplash.com/photo-1512038157504-ba8d2781700e" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl flex items-center justify-center">
                    <Button onClick={() => downloadImage(1)} className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                  <div className="absolute top-3 left-3 bg-black/70 text-white text-xs px-2 py-1 rounded-full">#2</div>
                </motion.div>
                <motion.div
                  className="relative group"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.3 }}
                >
                  <img  alt={`Miniature générée 3`} className="w-full aspect-video object-cover rounded-xl shadow-lg" src="https://images.unsplash.com/photo-1512038157504-ba8d2781700e" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl flex items-center justify-center">
                    <Button onClick={() => downloadImage(2)} className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                  <div className="absolute top-3 left-3 bg-black/70 text-white text-xs px-2 py-1 rounded-full">#3</div>
                </motion.div>
                <motion.div
                  className="relative group"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.4 }}
                >
                  <img  alt={`Miniature générée 4`} className="w-full aspect-video object-cover rounded-xl shadow-lg" src="https://images.unsplash.com/photo-1580728371486-c17d7e73f619" />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl flex items-center justify-center">
                    <Button onClick={() => downloadImage(3)} className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                  <div className="absolute top-3 left-3 bg-black/70 text-white text-xs px-2 py-1 rounded-full">#4</div>
                </motion.div>
              </div>
              <div className="mt-4 p-4 bg-black/30 rounded-xl">
                <p className="text-sm text-purple-300">
                  <strong>Prompt utilisé:</strong> {generatedImages[0]?.prompt}
                </p>
                <p className="text-sm text-purple-300 mt-1">
                  <strong>Style:</strong> {styles.find(s => s.id === generatedImages[0]?.style)?.name}
                </p>
              </div>
            </>
          )}
        </motion.div>
      )}
    </div>
  );
};

export default ThumbnailGenerator;