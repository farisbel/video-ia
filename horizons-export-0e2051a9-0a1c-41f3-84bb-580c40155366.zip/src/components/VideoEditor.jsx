import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Play, Pause, Volume2, VolumeX, Download, Type, Sparkles, Scissors, Zap, FileVideo, Clock, Settings, SlidersHorizontal, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Slider } from '@/components/ui/slider';

const VideoEditor = () => {
  const [videoFile, setVideoFile] = useState(null);
  const [videoFileName, setVideoFileName] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState([50]);
  const [subtitlesEnabled, setSubtitlesEnabled] = useState(false);
  const [smartCutEnabled, setSmartCutEnabled] = useState(false);
  const [audioEnhancementEnabled, setAudioEnhancementEnabled] = useState(false);
  const [selectedEffect, setSelectedEffect] = useState(null);
  const [effectConfig, setEffectConfig] = useState({
    fade: 50,
    zoom: 110,
    blur: 4,
    vintage: 100,
  });
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  const effects = [
    { id: 'fade', name: 'Fondu', icon: Sparkles, color: 'from-purple-500 to-pink-500', unit: '%', min: 0, max: 100, step: 1 },
    { id: 'zoom', name: 'Zoom', icon: Zap, color: 'from-blue-500 to-cyan-500', unit: '%', min: 100, max: 200, step: 1 },
    { id: 'blur', name: 'Flou', icon: Settings, color: 'from-green-500 to-emerald-500', unit: 'px', min: 0, max: 20, step: 1 },
    { id: 'vintage', name: 'Vintage', icon: Clock, color: 'from-orange-500 to-red-500', unit: '%', min: 0, max: 100, step: 1 }
  ];

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(URL.createObjectURL(file));
      setVideoFileName(file.name);
      toast({
        title: "✅ Vidéo chargée !",
        description: "Votre vidéo est prête pour le montage.",
      });
    } else {
      toast({
        title: "❌ Erreur",
        description: "Veuillez sélectionner un fichier vidéo valide.",
        variant: "destructive"
      });
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleSeek = (value) => {
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
      setCurrentTime(value[0]);
    }
  };

  const handleVolumeChange = (value) => {
    setVolume(value);
    if (videoRef.current) {
      videoRef.current.volume = value[0] / 100;
    }
  };

  const generateSubtitles = () => {
    setSubtitlesEnabled(!subtitlesEnabled);
    toast({
      title: subtitlesEnabled ? "Sous-titres désactivés" : "🎯 Sous-titres générés !",
      description: subtitlesEnabled ? "Les sous-titres ont été retirés." : "Les sous-titres automatiques ont été ajoutés à votre vidéo.",
    });
  };

  const toggleSmartCut = () => {
    setSmartCutEnabled(!smartCutEnabled);
    toast({
      title: !smartCutEnabled ? "🎬 Découpage intelligent activé" : "🎬 Découpage intelligent désactivé",
      description: !smartCutEnabled ? "L'IA va supprimer les silences pour vous." : "L'effet de découpage a été retiré.",
    });
  };

  const toggleAudioEnhancement = () => {
    setAudioEnhancementEnabled(!audioEnhancementEnabled);
    toast({
      title: !audioEnhancementEnabled ? "🎵 Amélioration audio activée" : "🎵 Amélioration audio désactivée",
      description: !audioEnhancementEnabled ? "La clarté de votre audio a été améliorée." : "L'amélioration audio a été retirée.",
    });
  };

  const applyEffect = (effect) => {
    if (selectedEffect?.id === effect.id) {
      setSelectedEffect(null);
    } else {
      setSelectedEffect(effect);
    }
  };

  const handleEffectConfigChange = (value) => {
    if (selectedEffect) {
      setEffectConfig(prev => ({ ...prev, [selectedEffect.id]: value[0] }));
    }
  };

  const exportVideo = () => {
    if (!videoFile) return;
    toast({
      title: "🚀 Export en cours...",
      description: "Votre vidéo est en cours d'export sans watermark !",
    });
    const link = document.createElement('a');
    link.href = videoFile;
    const cleanFileName = videoFileName.substring(0, videoFileName.lastIndexOf('.'));
    link.download = `${cleanFileName}-VideoAI-Studio.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({
      title: "✅ Export terminé !",
      description: "Votre vidéo a été téléchargée avec succès.",
    });
  };

  const formatTime = (time) => {
    if (isNaN(time) || time === 0) return '0:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const videoVariants = {
    initial: { opacity: 1, scale: 1 },
    active: (config) => ({
      opacity: config.fade ? 1 - (config.fade / 100) : 1,
      scale: config.zoom ? config.zoom / 100 : 1,
      transition: { duration: 0.5 }
    }),
  };

  const getActiveVariant = () => {
    if (!selectedEffect) return 'initial';
    return 'active';
  };

  const getCustomConfig = () => {
    if (!selectedEffect) return {};
    return { [selectedEffect.id]: effectConfig[selectedEffect.id] };
  };

  return (
    <div className="space-y-6">
      {!videoFile && (
        <motion.div
          className="bg-gradient-to-br from-purple-900/50 to-blue-900/50 backdrop-blur-lg rounded-2xl p-8 border border-white/10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center">
            <motion.div
              className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4"
              whileHover={{ scale: 1.1, rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Upload className="w-10 h-10 text-white" />
            </motion.div>
            <h2 className="text-2xl font-bold text-white mb-2">Importez votre vidéo</h2>
            <p className="text-purple-300 mb-6">Glissez-déposez ou cliquez pour sélectionner votre fichier vidéo</p>
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <FileVideo className="w-5 h-5 mr-2" />
              Choisir une vidéo
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </motion.div>
      )}

      {videoFile && (
        <motion.div
          className="bg-gradient-to-br from-gray-900/80 to-black/80 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="relative mb-4 overflow-hidden rounded-xl">
            <motion.video
              ref={videoRef}
              src={videoFile}
              className="w-full rounded-xl shadow-2xl"
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              variants={videoVariants}
              animate={getActiveVariant()}
              custom={getCustomConfig()}
              style={{
                filter: selectedEffect?.id === 'blur' ? `blur(${effectConfig.blur}px)` :
                        selectedEffect?.id === 'vintage' ? `sepia(${effectConfig.vintage / 100}) contrast(1.2) saturate(${1 - (effectConfig.vintage / 200)})` :
                        'none'
              }}
            />
            <AnimatePresence>
              {subtitlesEnabled && (
                <motion.div 
                  className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-lg text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                >
                  Ceci est un exemple de sous-titre généré par IA.
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <Button onClick={togglePlay} variant="ghost" size="icon" className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-full">
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
              </Button>
              <div className="flex-1">
                <Slider value={[currentTime]} max={duration} step={0.1} onValueChange={handleSeek} className="w-full" />
                <div className="flex justify-between text-sm text-purple-300 mt-1">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Button onClick={toggleMute} variant="ghost" size="icon" className="text-purple-300 hover:text-white">
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </Button>
                <div className="w-20">
                  <Slider value={volume} max={100} step={1} onValueChange={handleVolumeChange} />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {videoFile && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div
            className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10 space-y-4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-xl font-bold text-white flex items-center">
              <Sparkles className="w-6 h-6 mr-2 text-purple-400" />
              Effets Magiques
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {effects.map((effect) => (
                <motion.button
                  key={effect.id}
                  onClick={() => applyEffect(effect)}
                  className={`p-4 rounded-xl border transition-all duration-300 ${
                    selectedEffect?.id === effect.id
                      ? 'border-purple-500 bg-purple-500/20'
                      : 'border-white/10 bg-white/5 hover:border-purple-500/50'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <div className={`w-8 h-8 bg-gradient-to-r ${effect.color} rounded-lg flex items-center justify-center mb-2`}>
                    <effect.icon className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm font-medium text-white">{effect.name}</span>
                </motion.button>
              ))}
            </div>
            <AnimatePresence>
              {selectedEffect && (
                <motion.div
                  className="space-y-3"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                >
                  <h4 className="text-lg font-semibold text-white flex items-center">
                    <SlidersHorizontal className="w-5 h-5 mr-2 text-purple-300" />
                    Configurer: {selectedEffect.name}
                  </h4>
                  <div className="flex items-center space-x-4">
                    <Slider
                      value={[effectConfig[selectedEffect.id]]}
                      min={selectedEffect.min}
                      max={selectedEffect.max}
                      step={selectedEffect.step}
                      onValueChange={handleEffectConfigChange}
                      className="flex-1"
                    />
                    <span className="text-purple-300 font-mono w-16 text-right">
                      {effectConfig[selectedEffect.id]}{selectedEffect.unit}
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          <motion.div
            className="bg-gradient-to-br from-blue-900/50 to-indigo-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <Zap className="w-6 h-6 mr-2 text-blue-400" />
              Outils IA
            </h3>
            <div className="space-y-3">
              <Button onClick={generateSubtitles} className={`w-full justify-start ${subtitlesEnabled ? 'bg-green-500/20 border-green-500/30 text-green-400' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'} border`}>
                {subtitlesEnabled ? <CheckCircle className="w-5 h-5 mr-3 text-green-400" /> : <Type className="w-5 h-5 mr-3" />}
                {subtitlesEnabled ? 'Sous-titres activés' : 'Générer sous-titres IA'}
              </Button>
              <Button onClick={toggleSmartCut} className={`w-full justify-start ${smartCutEnabled ? 'bg-green-500/20 border-green-500/30 text-green-400' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'} border`}>
                {smartCutEnabled ? <CheckCircle className="w-5 h-5 mr-3 text-green-400" /> : <Scissors className="w-5 h-5 mr-3" />}
                {smartCutEnabled ? 'Découpage intelligent activé' : 'Découpage intelligent'}
              </Button>
              <Button onClick={toggleAudioEnhancement} className={`w-full justify-start ${audioEnhancementEnabled ? 'bg-green-500/20 border-green-500/30 text-green-400' : 'bg-white/5 border-white/10 text-white hover:bg-white/10'} border`}>
                {audioEnhancementEnabled ? <CheckCircle className="w-5 h-5 mr-3 text-green-400" /> : <Volume2 className="w-5 h-5 mr-3" />}
                {audioEnhancementEnabled ? 'Amélioration audio activée' : 'Amélioration audio IA'}
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {videoFile && (
        <motion.div
          className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 backdrop-blur-lg rounded-2xl p-6 border border-white/10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white mb-2">Export sans watermark</h3>
              <p className="text-green-300">Téléchargez votre vidéo en qualité HD, totalement gratuit !</p>
            </div>
            <Button onClick={exportVideo} className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300">
              <Download className="w-5 h-5 mr-2" />
              Exporter HD
            </Button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default VideoEditor;