import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Video, Image, Wand2, Scissors, Volume2, Sparkles, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import VideoEditor from '@/components/VideoEditor';
import ThumbnailGenerator from '@/components/ThumbnailGenerator';

function App() {
  const [activeTab, setActiveTab] = useState('editor');

  const features = [
    {
      icon: Scissors,
      title: "Découpage Auto",
      description: "Supprime les silences et hésitations"
    },
    {
      icon: Volume2,
      title: "Audio Clair",
      description: "Amélioration de la qualité sonore"
    },
    {
      icon: Sparkles,
      title: "Effets Magiques",
      description: "Transitions et effets spectaculaires"
    },
    {
      icon: Image,
      title: "Miniatures IA",
      description: "Création d'images avec prompts"
    }
  ];

  return (
    <>
      <Helmet>
        <title>VideoAI Studio - Montage Vidéo IA Gratuit Sans Watermark</title>
        <meta name="description" content="Plateforme de montage vidéo IA gratuite et illimitée. Créez des vidéos professionnelles avec sous-titres automatiques, effets spectaculaires et miniatures générées par IA." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        {/* Header */}
        <header className="border-b border-white/10 backdrop-blur-lg bg-black/20">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <motion.div 
                className="flex items-center space-x-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <Video className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                    VideoAI Studio
                  </h1>
                  <p className="text-xs text-purple-300">Gratuit • Illimité • Sans Watermark</p>
                </div>
              </motion.div>

              <motion.div 
                className="flex items-center space-x-2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                <div className="flex items-center space-x-1 bg-gradient-to-r from-green-500/20 to-emerald-500/20 px-3 py-1 rounded-full border border-green-500/30">
                  <Star className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-400 font-medium">100% Gratuit</span>
                </div>
              </motion.div>
            </div>
          </div>
        </header>

        {/* Navigation Tabs */}
        <div className="container mx-auto px-4 py-6">
          <motion.div 
            className="flex justify-center space-x-1 bg-black/30 backdrop-blur-lg rounded-2xl p-2 max-w-md mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Button
              variant={activeTab === 'editor' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('editor')}
              className={`flex-1 ${activeTab === 'editor' 
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg' 
                : 'text-purple-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Video className="w-4 h-4 mr-2" />
              Éditeur Vidéo
            </Button>
            <Button
              variant={activeTab === 'thumbnail' ? 'default' : 'ghost'}
              onClick={() => setActiveTab('thumbnail')}
              className={`flex-1 ${activeTab === 'thumbnail' 
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg' 
                : 'text-purple-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Image className="w-4 h-4 mr-2" />
              Miniatures IA
            </Button>
          </motion.div>
        </div>

        {/* Features Banner */}
        <motion.div 
          className="container mx-auto px-4 mb-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-lg rounded-xl p-4 border border-white/10 hover:border-purple-500/30 transition-all duration-300"
                whileHover={{ scale: 1.05, y: -5 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
              >
                <feature.icon className="w-8 h-8 text-purple-400 mb-2" />
                <h3 className="font-semibold text-white text-sm mb-1">{feature.title}</h3>
                <p className="text-xs text-purple-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="container mx-auto px-4 pb-8">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4 }}
          >
            {activeTab === 'editor' && <VideoEditor />}
            {activeTab === 'thumbnail' && <ThumbnailGenerator />}
          </motion.div>
        </div>

        <Toaster />
      </div>
    </>
  );
}

export default App;